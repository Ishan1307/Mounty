package com.example.mounty;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class ViewRating extends Fragment {


    public ViewRating() {
        // Required empty public constructor
    }

    ListView lv;
    TextView tv;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v1=inflater.inflate(R.layout.fragment_view_rating, container, false);
        lv=v1.findViewById(R.id.lv1);
        tv=v1.findViewById(R.id.tv2);
        MyDatabase md=new MyDatabase(getContext());
        ArrayList<String> al=md.viewRating();
        if(al.size()==0)
        {
            lv.setVisibility(View.INVISIBLE);
            tv.setVisibility(View.VISIBLE);
        }
        else {
            tv.setVisibility(View.INVISIBLE);
            lv.setVisibility(View.VISIBLE);
            ArrayAdapter<String> adapter=new ArrayAdapter<String>(getContext(),R.layout.list1,al);
            lv.setAdapter(adapter);
        }
        return v1;
    }

}
