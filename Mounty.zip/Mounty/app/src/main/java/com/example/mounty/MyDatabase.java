package com.example.mounty;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

public class MyDatabase extends SQLiteOpenHelper {

    private static String dbname="mydatabase";
    private static int version=1;
    Context ct;
    MyDatabase(Context ct)
    {
        super(ct,dbname,null,version);
        this.ct=ct;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String s="create table movie(name text,rating text,des text)";
        db.execSQL(s);
    }
    public void addRating(String name,String rating,String des)
    {
        SQLiteDatabase db=getWritableDatabase();

        ContentValues cv=new ContentValues();
        cv.put("name",name);
        cv.put("rating",rating);
        cv.put("des",des);
        db.insert("movie",null,cv);
        Toast.makeText(ct, "Insert Completed", Toast.LENGTH_SHORT).show();
    }
    public ArrayList<String> viewRating()
    {
        SQLiteDatabase db=getReadableDatabase();
        String s="select * from movie";
        Cursor cr=db.rawQuery(s,null);

        ArrayList<String> al=new ArrayList<>();
        while (cr.moveToNext())
        {
            String s1=cr.getString(0);
            String s2=cr.getString(1);
            String s3=cr.getString(2);
            String s6="Movie Name is: "+s1+"\nRating is: "+s2+"\nDiscription: "+s3;
            al.add(s6);
        }
        return al;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
