package com.example.mounty;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;


public class AddMovie extends Fragment {

    Button b1;
    EditText ed1,ed2;
    RatingBar rb;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v1=inflater.inflate(R.layout.fragment_add_movie, container, false);
        b1=v1.findViewById(R.id.b1);
        ed1=v1.findViewById(R.id.ed1);
        ed2=v1.findViewById(R.id.ed2);
        rb=v1.findViewById(R.id.rb1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=ed1.getText().toString();
                String s2=ed2.getText().toString();
                String s3=rb.getRating()+"/"+rb.getNumStars();
                MyDatabase md=new MyDatabase(getContext());
                md.addRating(s1,s3,s2);
            }
        });
        return v1;
    }

}
