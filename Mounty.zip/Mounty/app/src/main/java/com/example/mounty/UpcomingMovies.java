package com.example.mounty;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpcomingMovies extends Fragment {


    public UpcomingMovies() {
        // Required empty public constructor
    }


    ListView lv;
    String[] ar={"Movie:Hawayein \nProduction:OK Movies\nRelease Date:May 1","Movie:Coolie No.1 \nProduction:Pooja Entertainment\nRelease Date:May 1","Movie:Dil Bechara \nProduction:OK Movies\nRelease Date:May 1",
            "Movie:The Girl on The Train \nProduction:Reliance Entertaitment\nRelease Date:May 8","Movie:Shakuntla Devi \nProduction:Sony Pictures\nRelease Date:May 8","Movie:Laxmi Bomb \nProduction:Fox Star Studions\nRelease Date:May 15",
            "Movie:Radha \nProduction:Salman Khan Films\nRelease Date:May 22"};
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v1=inflater.inflate(R.layout.fragment_upcoming_movies, container, false);
        lv=v1.findViewById(R.id.lv1);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(getContext(),R.layout.list1,ar);
        lv.setAdapter(adapter);
        return v1;
    }

}
